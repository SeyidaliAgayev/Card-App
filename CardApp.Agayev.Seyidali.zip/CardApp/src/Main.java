import service.impl.UserManagementServiceImpl;

public class Main {
    public static void main(String[] args) {
        new UserManagementServiceImpl().userManagement();
    }
}