package service;

public interface UserService {
    void signIn();
}
