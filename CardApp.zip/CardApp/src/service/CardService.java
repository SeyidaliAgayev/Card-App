package service;

public interface CardService {
    void cardToCard(long userId);
    void showBalance(long userId);
}
