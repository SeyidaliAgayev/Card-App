package service;

public interface CardManagementService {
    void cardManagement(long userId);
}
