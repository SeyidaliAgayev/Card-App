package service;

public interface UserManagementService {
    void userManagement();
}
